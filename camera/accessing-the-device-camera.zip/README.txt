A Pen created at CodePen.io. You can find this one at http://codepen.io/justinklemm/pen/cDrFo.

 Implementation of Matt West's excellent "Accessing the Device Camera with getUserMedia" article found at http://blog.teamtreehouse.com/accessing-the-device-camera-with-getusermedia