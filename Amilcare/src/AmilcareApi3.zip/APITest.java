
import interf.AmilcareUI;


/**
 * It performs a basic test of the Amilcare API.
 */
public class APITest {
   /**
    * It tests the API.
    * @param args the filename of the scenario file you want to test the API for.
    * Note: please create the scenario file by setting the parameters with the GUI and saving the scenario to a file.
    */
   public static void main(String[] args) {
      checkExpiryDate();
      runAmilcare(args);
      System.exit(0);
   }

   private static void runAmilcare(String[] args) {
      try {
         AmilcareApi.API.setDialogBoxesActive(true, null);           //it just prints on the standard output
         System.out.println("Loading scenario " + args[0] + "...");
         AmilcareApi.API.loadScenario(args[0]);

         System.out.println("Learning...");
         AmilcareApi.API.learnRules();

         System.out.println("Extracting information...");
         AmilcareApi.API.extractInformation();

         System.out.println("\n\n------------------- Results -------------------");
         AmilcareApi.API.printTaggingResults();

      } catch (Exception e) {
         System.out.println("There was a problem running Amilcare: " + e);
      }
   }

}
