/**
 * Created by fabio on 26/02/15.
 */
var fs = require('fs');

var Twit = require('twit');
var client = new Twit({
    consumer_key: '8DagPRHVMdak39IlUuASw',
    consumer_secret: 'vqGnbAKvwnYGTmxZjxnPz7DD46iLpF1CC4OhZQXL0',
    access_token: '17390300-NWxo1S3S8ctPjTnoZTjbUmy2lbCmZs4lHLclGzRQg',
    access_token_secret: 'dfMzkmPDcBkuSpCS6YmXhjoJNati7hBBCpLWmywk'
});


//  search twitter for all tweets containing the word 'flower'
// since Nov. 11, 2015

client.get('search/tweets', {q: 'from:katyperry ', count: 15},
    function (err, data, response) {
        for (var indx in data.statuses) {
            var tweet = data.statuses[indx];
            var user = tweet.user;
            var imageUrl = user.profile_image_url;
            var name = user.name;
            var screenname = user.screen_name;
            var time = tweet.created_at;
            var text = tweet.text;

            console.log(time + ": " + name + " " + text);

            fs.writeFile("ambassadors_files/cmd.js", "displayTweets(" + JSON.stringify(data.statuses) + ");", function (err) {
                if (err) {
                    return console.log(err);
                }

            });
        }
        console.log(data.statuses.length + ' tweets retrieved!');

    })
