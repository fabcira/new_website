/**
 * Created by fabio on 26/02/15.
 */
var fs = require('fs');

var Twit = require('twit');
var client = new Twit({
    consumer_key: '8DagPRHVMdak39IlUuASw',
    consumer_secret: 'vqGnbAKvwnYGTmxZjxnPz7DD46iLpF1CC4OhZQXL0',
    access_token: '17390300-NWxo1S3S8ctPjTnoZTjbUmy2lbCmZs4lHLclGzRQg',
    access_token_secret: 'dfMzkmPDcBkuSpCS6YmXhjoJNati7hBBCpLWmywk'
});


client.get('statuses/user_timeline', {screen_name: 'juanmata8'},
    function (err, tweets, response) {
        //console.log(tweets);
        for (var indx in tweets) {
            var tweet = tweets[indx];
            var user = tweet.user;
            var imageUrl = user.profile_image_url;
            var name = user.name;
            var screenname = user.screen_name;
            var time = tweet.created_at;
            var text = tweet.text;

            console.log(time + ": " + name + " " + text);

            fs.writeFile("ambassadors_files/cmd.js", "displayTweets(" + JSON.stringify(tweets) + ");", function (err) {
                if (err) {
                    return console.log(err);
                }

            });
        }
        console.log(tweets.length + ' tweets retrieved!');

    })
